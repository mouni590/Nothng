package com.cg.productapp.service;

import java.util.List;

import com.cg.productapp.bean.Product;
import com.cg.productapp.service.ProductService;

public interface ProductService {
	List<Product> getAllProducts();
	Product getProductById(int id);
	void updateProduct(Product pro);
	void addProduct(Product pro);
	void deleteProduct(int id);
	 List<Product> getProductByCategory(String category);
	 List<Product> getProductByPrice(int  price1, int price2);
	 
}
