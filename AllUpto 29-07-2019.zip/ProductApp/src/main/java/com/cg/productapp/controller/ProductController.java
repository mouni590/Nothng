package com.cg.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.productapp.bean.Product;
import com.cg.productapp.service.ProductService;


@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping("/api/products")
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}
	@RequestMapping("/api/products/{id}")
	public Product getAllProducts(@PathVariable int id) {
		return productService.getProductById(id);
	}
	@RequestMapping(value = "/api/products/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with the " + id + "Deleted", HttpStatus.OK);
	}
	@RequestMapping(value = "/api/products", method = RequestMethod.POST)
	public ResponseEntity<String> addProduct(@RequestBody Product pro) {
		productService.addProduct(pro);
		return new ResponseEntity<String>("Successfull", HttpStatus.OK);
	}
	@RequestMapping(value="/api/products/{id}",method=RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(@RequestBody Product pro){
		productService.updateProduct(pro);
	return new ResponseEntity<String>("Product Updated",HttpStatus.OK);

}
	@RequestMapping("/api/products/category")
	public List<Product> getProductByCategory(@RequestParam String category){
		return productService.getProductByCategory(category);
	}

	@RequestMapping("/api/products/price")
	public List<Product> getProductByPrice(@RequestParam int price1, int price2){
		return productService.getProductByPrice(price1,price2);
	}
	
}
