package com.cg.custapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.custapp.exception.CustomerException;

@ControllerAdvice
public class CustomerExceptionHandler {
	@ExceptionHandler(CustomerException.class)
	 public ResponseEntity<String> handleError(Exception ex){
		 return new ResponseEntity<String>("Oops!!"+ex.getMessage(),HttpStatus.CONFLICT);
		 
	 }

}
