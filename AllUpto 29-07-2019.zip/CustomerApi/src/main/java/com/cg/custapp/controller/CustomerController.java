package com.cg.custapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.custapp.bean.Customer;
import com.cg.custapp.exception.CustomerException;
import com.cg.custapp.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	@RequestMapping("/api/customers")
	public List<Customer> getAllCustomers() throws CustomerException {
		return customerService.getAllCustomers();
	}

	@RequestMapping(value = "/api/customers", method = RequestMethod.POST)
	public List<Customer> addCustomer(@RequestBody Customer cust) throws CustomerException {

		return customerService.addCustomer(cust);
	}

	@RequestMapping("/api/customers/{id}")
	public Customer getCustomerById(@PathVariable int id) throws CustomerException {
		return customerService.getCustomerById(id);

	}

	@RequestMapping("/api/customers/cities/{city}")
	public List<Customer> getCustomerByCity(@PathVariable String city) throws CustomerException {
		return customerService.getCustomerByCity(city);

	}

	@RequestMapping(value="/api/customers/delete/{id}",method=RequestMethod.DELETE)
	 public ResponseEntity<String> deleteCustomer(@PathVariable int id) throws CustomerException{ 
		customerService.deleteCustomer(id);
		return new ResponseEntity<String>("Customer with the "+ id+ "Deleted",HttpStatus.OK);
	}

	 @RequestMapping(value="/api/customers/{id}",method=RequestMethod.PUT)
	 public List<Customer> updateCustomer(@PathVariable int id ,@RequestBody Customer cust) throws CustomerException{
	
	 return  customerService.updateCustomer(id,cust); 
	  }
	 
	 
	
	
	
	/*
	 * @RequestMapping("/api/customers/{id}") public Customer
	 * getAllCustomerById(@PathVariable int id) throws CustomerException{ return
	 * customerService.getCustomerById(id); }
	 * 
	 * 
	 * 
	 * }
	 * 
	 * @RequestMapping(value="/api/customers/{id}",method=RequestMethod.PUT) public
	 * ResponseEntity<String> updateCustomer(@RequestBody Customer cust){
	 * customerService.updateCustomer(cust); return new
	 * ResponseEntity<String>("Customer Updated",HttpStatus.OK);
	 * 
	 * }
	 * 
	 * @RequestMapping("/api/customers/name") public List<Customer>
	 * CustomerByName(@RequestParam String name){ return
	 * customerService.getCustomereByName(name); }
	 */
}
