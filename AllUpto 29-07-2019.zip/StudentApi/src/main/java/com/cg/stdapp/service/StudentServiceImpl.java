package com.cg.stdapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.stdapp.bean.Student;
import com.cg.stdapp.dao.StudentDao;

@Service
public class StudentServiceImpl  implements StudentService{
	@Autowired
	StudentDao studentDao;

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}

	@Override
	public Student getStudentById(int id) {
		// TODO Auto-generated method stub
		return studentDao.findById(id).get();
	}

	@Override
	public void updateStudent(Student std) {
		// TODO Auto-generated method stub
		studentDao.save(std);
		
	}

	@Override
	public void addStudent(Student std) {
		// TODO Auto-generated method stub
		studentDao.save(std);
	}

	@Override
	public void deleteStudent(int id) {
		// TODO Auto-generated method stub
		studentDao.deleteById(id);
	}

	@Override
	public List<Student> getStudentByAge(int age) {
		// TODO Auto-generated method stub
		return studentDao.getStudentByAge(age);
	}

}
