package com.cg.stdapp.service;

import java.util.List;

import com.cg.stdapp.bean.Student;

public interface StudentService {

	List<Student> getAllStudents();
	Student getStudentById(int id);
	void updateStudent(Student std);
	void addStudent(Student std);
	void deleteStudent(int id);
	List<Student> getStudentByAge(int age);

}
