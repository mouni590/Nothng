package com.cg.stdapp.controller;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.stdapp.bean.Student;
import com.cg.stdapp.service.StudentService;


@RestController
public class StudentController {

	@Autowired
	StudentService studentService;
	@RequestMapping("/api/students")
	public List<Student> getAllStudents(){
		return studentService.getAllStudents();
	}
	@RequestMapping("/api/students/{id}")
	public Student getAllEmployees(@PathVariable int id){
		return studentService.getStudentById(id);
	}
	
	@RequestMapping(value="/api/students/{id}",method=RequestMethod.DELETE)
    public ResponseEntity<String> deleteStudent(@PathVariable int id){
    	studentService.deleteStudent(id);
    	return new ResponseEntity<String>("Student with the "+ id+ "Deleted",HttpStatus.OK);
		
	}
	@RequestMapping(value="/api/students",method=RequestMethod.POST)
	public ResponseEntity<String> addStudent(@RequestBody Student std){
		studentService.addStudent(std);
		return new ResponseEntity<String>("Student Successfully Deleted",HttpStatus.OK);
	}
	@RequestMapping(value="/api/students/{id}",method=RequestMethod.PUT)
	public ResponseEntity<String> updateStudent(@RequestBody Student std){
	studentService.updateStudent(std);
	return new ResponseEntity<String>("Student Updated",HttpStatus.OK);

}
	@RequestMapping("/api/students/age/{age}")
	public List<Student> getStudentByAge(@PathVariable int age){
		return studentService.getStudentByAge(age);
	}

}